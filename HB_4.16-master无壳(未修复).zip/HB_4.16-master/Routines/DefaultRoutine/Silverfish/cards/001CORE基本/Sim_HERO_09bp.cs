namespace HREngine.Bots
{
	class Sim_HERO_09bp : Sim_CS1h_001 //* 次级治疗术 Lesser Heal
	{
		//<b>Hero Power</b>Restore #2 Health.
		//<b>英雄技能</b>恢复#2点生命值。


	}
}