namespace HREngine.Bots
{
	class Sim_HERO_07bp2 : Sim_AT_132_WARLOCK //* 灵魂分流 Soul Tap
	{
		//<b>Hero Power</b>Draw a card.
		//<b>英雄技能</b>抽一张牌。


	}
}