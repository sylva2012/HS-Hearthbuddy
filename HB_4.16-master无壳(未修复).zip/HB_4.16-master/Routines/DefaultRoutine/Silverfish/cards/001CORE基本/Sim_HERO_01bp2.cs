namespace HREngine.Bots
{
	class Sim_HERO_01bp2 : Sim_AT_132_WARRIOR //* 铜墙铁壁！ Tank Up!
	{
		//<b>Hero Power</b>Gain 4 Armor.
		//<b>英雄技能</b>获得4点护甲值。


	}
}