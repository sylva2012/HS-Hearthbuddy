namespace HREngine.Bots
{
	class Sim_HERO_09bp2 : Sim_AT_132_PRIEST //* 治疗术 Heal
	{
		//<b>Hero Power</b>Restore #4 Health.
		//<b>英雄技能</b>恢复#4点生命值。


	}
}