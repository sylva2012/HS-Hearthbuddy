namespace HREngine.Bots
{
	class Sim_HERO_04bp : Sim_CS2_101 //* 援军 Reinforce
	{
		//<b>Hero Power</b>Summon a 1/1 Silver Hand Recruit.
		//<b>英雄技能</b>召唤一个1/1的白银之手新兵。


	}
}