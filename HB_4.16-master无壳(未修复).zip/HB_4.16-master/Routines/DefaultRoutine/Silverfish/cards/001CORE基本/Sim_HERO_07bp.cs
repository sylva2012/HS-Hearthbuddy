namespace HREngine.Bots
{
	class Sim_HERO_07bp : Sim_CS2_056 //* 生命分流 Life Tap
	{
		//<b>Hero Power</b>Draw a card and take $2 damage.
		//<b>英雄技能</b>抽一张牌并受到$2点伤害。


	}
}