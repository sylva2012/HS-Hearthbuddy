namespace HREngine.Bots
{
	class Sim_HERO_10 : SimTemplate //* 伊利丹·怒风 Illidan Stormrage
	{
		//
		//


	}
}