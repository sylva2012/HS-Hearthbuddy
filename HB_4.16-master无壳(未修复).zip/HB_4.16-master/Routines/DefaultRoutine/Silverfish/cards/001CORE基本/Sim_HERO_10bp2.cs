namespace HREngine.Bots
{
	class Sim_HERO_10bp2 : Sim_HERO_10p_UP //* 恶魔之咬 Demon's Bite
	{
		//[x]<b>Hero Power</b>+2 Attack this turn.
		//<b>英雄技能</b>在本回合中获得+2攻击力。


	}
}