namespace HREngine.Bots
{
	class Sim_HERO_02bp : Sim_CS2_049 //* 图腾召唤 Totemic Call
	{
		//<b>Hero Power</b>Summon a random Totem.
		//<b>英雄技能</b>随机召唤一个图腾。


	}
}