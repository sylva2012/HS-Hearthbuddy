namespace HREngine.Bots
{
	class Sim_HERO_03bp2 : Sim_AT_132_ROGUE //* 浸毒匕首 Poisoned Daggers
	{
		//<b>Hero Power</b>Equip a 2/2 Weapon.
		//<b>英雄技能</b>装备一把2/2的匕首。


	}
}