namespace HREngine.Bots
{
	class Sim_HERO_05bp2 : Sim_AT_132_HUNTER //* 弩炮射击 Ballista Shot
	{
		//<b>Hero Power</b>Deal $3 damage.
		//<b>英雄技能</b>造成$3点伤害。


	}
}