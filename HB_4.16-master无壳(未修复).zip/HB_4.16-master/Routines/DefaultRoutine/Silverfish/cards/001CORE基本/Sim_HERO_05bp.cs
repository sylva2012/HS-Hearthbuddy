namespace HREngine.Bots
{
	class Sim_HERO_05bp : Sim_DS1h_292 //* 稳固射击 Steady Shot
	{
		//<b>Hero Power</b>Deal $2 damage.
		//<b>英雄技能</b>造成$2点伤害。


	}
}