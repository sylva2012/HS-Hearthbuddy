namespace HREngine.Bots
{
	class Sim_HERO_04bp2 : Sim_AT_132_PALADIN //* 白银之手 The Silver Hand
	{
		//<b>Hero Power</b>Summon two 1/1 Recruits.
		//<b>英雄技能</b>召唤两个1/1的白银之手新兵。


	}
}