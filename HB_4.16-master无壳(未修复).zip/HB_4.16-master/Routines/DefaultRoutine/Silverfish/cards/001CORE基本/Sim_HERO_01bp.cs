namespace HREngine.Bots
{
	class Sim_HERO_01bp : Sim_CS2_102 //* 全副武装！ Armor Up!
	{
		//<b>Hero Power</b>Gain 2 Armor.
		//<b>英雄技能</b>获得2点护甲值。


	}
}