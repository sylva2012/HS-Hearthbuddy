namespace HREngine.Bots
{
	class Sim_HERO_03bp : Sim_CS2_083b //* 匕首精通 Dagger Mastery
	{
		//<b>Hero Power</b>Equip a 1/2 Dagger.
		//<b>英雄技能</b>装备一把1/2的匕首。


	}
}