namespace HREngine.Bots
{
	class Sim_HERO_06bp : Sim_CS2_017 //* 变形 Shapeshift
	{
		//<b>Hero Power</b>+1 Attack this turn.+1 Armor.
		//<b>英雄技能</b>本回合+1攻击力。+1护甲值。


	}
}