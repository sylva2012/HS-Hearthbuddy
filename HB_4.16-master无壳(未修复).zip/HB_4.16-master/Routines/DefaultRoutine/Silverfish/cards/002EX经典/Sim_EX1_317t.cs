using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_317t : SimTemplate //worthlessimp
	{

//    i&gt;euch sind die dämonen ausgegangen! aber zum glück gibt es ja noch wichtel .../i&gt;
		

	}
}