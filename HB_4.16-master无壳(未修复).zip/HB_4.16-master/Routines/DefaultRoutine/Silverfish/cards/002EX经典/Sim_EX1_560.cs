using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_560 : SimTemplate //nozdormu
	{

//    spieler haben nur jeweils 15 sekunden für ihren zug.

        //todo

	}
}