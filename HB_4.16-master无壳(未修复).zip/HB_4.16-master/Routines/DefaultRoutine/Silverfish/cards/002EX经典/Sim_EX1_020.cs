using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_020 : SimTemplate //scarletcrusader
	{

//    gottesschild/


	}
}