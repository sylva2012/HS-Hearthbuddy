using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_GIL_130 : SimTemplate //* 阴郁的牡鹿
	{
		//<b>嘲讽，战吼：</b>如果你的牌库中只有法力值消耗为奇数的牌，则获得+2/+2。


	}
}