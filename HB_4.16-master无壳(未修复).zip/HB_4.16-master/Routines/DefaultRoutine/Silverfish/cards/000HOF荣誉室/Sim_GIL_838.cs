using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_GIL_838 : SimTemplate //* 黑猫
	{
		//<b>法术伤害+1，战吼：</b>如果你的牌库中只有法力值消耗为奇数的牌，抽一张牌。


	}
}