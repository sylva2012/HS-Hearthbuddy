using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_GIL_837 : SimTemplate //* 闪光飞蛾
	{
		//<b>战吼：</b>如果你的牌库中只有法力值消耗为奇数的牌，使你所有其他随从的生命值翻倍。


	}
}