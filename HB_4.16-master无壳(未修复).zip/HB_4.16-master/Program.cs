﻿using System;

namespace 三合一炉石兄弟汉化版2020._1._17
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
