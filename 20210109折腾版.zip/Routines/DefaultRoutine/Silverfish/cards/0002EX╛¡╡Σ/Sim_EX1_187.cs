using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_187 : SimTemplate //* 奥术吞噬者 Arcane Devourer
	{
		//Whenever you cast a spell, gain +2/+2.
		//每当你施放一个法术，便获得+2/+2。
		
		
	}
}
