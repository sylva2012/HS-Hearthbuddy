using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_182 : SimTemplate //* 窃取 Pilfer
	{
		//Add a random card from another class to_your hand.
		//随机将一张其他职业的卡牌置入你的手牌。
		
		
	}
}
