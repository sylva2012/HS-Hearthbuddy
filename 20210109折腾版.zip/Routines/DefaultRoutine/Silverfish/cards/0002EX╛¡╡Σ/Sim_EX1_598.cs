using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_598 : SimTemplate //* 小鬼 Imp
	{
		//
		//
		
		
	}
}
