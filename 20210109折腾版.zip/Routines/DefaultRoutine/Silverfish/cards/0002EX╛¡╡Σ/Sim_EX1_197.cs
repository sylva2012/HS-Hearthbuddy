using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_197 : SimTemplate //* 暗言术：毁 Shadow Word: Ruin
	{
		//Destroy all minions with 5 or more Attack.
		//消灭所有攻击力大于或等于5的随从。
		
		
	}
}
