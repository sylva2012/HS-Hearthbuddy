using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_033 : SimTemplate //* 风怒鹰身人 Windfury Harpy
	{
		//<b>Windfury</b>
		//<b>风怒</b>
		
		
	}
}
