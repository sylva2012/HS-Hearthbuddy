using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_067 : SimTemplate //* 银色指挥官 Argent Commander
	{
		//<b>Charge</b><b>Divine Shield</b>
		//<b>冲锋</b><b>圣盾</b>
		
		
	}
}
