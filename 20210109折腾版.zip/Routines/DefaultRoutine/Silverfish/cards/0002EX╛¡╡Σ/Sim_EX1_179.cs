using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_179 : SimTemplate //* 冰刺 Icicle
	{
		//Deal $2 damage to a minion. If it's <b>Frozen</b>, draw a card.
		//对一个随从造成$2点伤害。如果它已被<b>冻结</b>，抽一张牌。
		
		
	}
}
