using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_190 : SimTemplate //* 大检察官怀特迈恩 High Inquisitor Whitemane
	{
		//<b>Battlecry:</b> Summon all friendly minions that died_this turn.
		//<b>战吼：</b>召唤所有在本回合中死亡的友方随从。
		
		
	}
}
