using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_538t : SimTemplate //* 猎犬 Hound
	{
		//<b>Charge</b>
		//<b>冲锋</b>
		
		
	}
}
