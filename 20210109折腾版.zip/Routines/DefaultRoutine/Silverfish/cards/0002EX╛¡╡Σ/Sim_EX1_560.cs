using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_560 : SimTemplate //* 诺兹多姆 Nozdormu
	{
		//Players only have 15 seconds to take their_turns.
		//所有玩家只有15秒的时间来进行他们的回合。
		
		
	}
}
