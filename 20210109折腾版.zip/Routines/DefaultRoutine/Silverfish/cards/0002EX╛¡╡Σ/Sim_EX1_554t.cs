using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_554t : SimTemplate //* 蛇 Snake
	{
		//
		//
		
		
	}
}
