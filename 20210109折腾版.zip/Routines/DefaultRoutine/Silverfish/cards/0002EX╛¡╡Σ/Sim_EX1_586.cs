using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_586 : SimTemplate //* 海巨人 Sea Giant
	{
		//Costs (1) less for each other minion on the battlefield.
		//战场上每有一个其他随从，该牌的法力值消耗便减少（1）点。
		
		
	}
}
