using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_DFX_002 : SimTemplate //* Time Warp Dummy FX Time Warp Dummy FX
	{
		//Holds the FX for playing Timewarp FX.
		//Holds the FX for playing Timewarp FX.
		
		
	}
}
