using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_179 : SimTemplate //* 森金持盾卫士 Sen'jin Shieldmasta
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
