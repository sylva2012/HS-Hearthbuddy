using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_201 : SimTemplate //* 熔火恶犬 Core Hound
	{
		//
		//
		
		
	}
}
