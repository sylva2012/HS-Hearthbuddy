using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS1_042 : SimTemplate //* 闪金镇步兵 Goldshire Footman
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
