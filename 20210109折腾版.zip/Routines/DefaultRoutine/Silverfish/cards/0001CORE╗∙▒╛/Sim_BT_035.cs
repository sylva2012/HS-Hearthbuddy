using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BT_035 : SimTemplate //* 混乱打击 Chaos Strike
	{
		//Give your hero +2_Attack this turn. Draw a card.
		//在本回合中，使你的英雄获得+2攻击力。抽一张牌。
		
		
	}
}
