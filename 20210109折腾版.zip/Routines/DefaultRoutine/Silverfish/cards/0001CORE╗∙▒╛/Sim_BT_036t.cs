using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BT_036t : SimTemplate //* 伊利达雷新兵 Illidari Initiate
	{
		//<b>Rush</b>
		//<b>突袭</b>
		
		
	}
}
