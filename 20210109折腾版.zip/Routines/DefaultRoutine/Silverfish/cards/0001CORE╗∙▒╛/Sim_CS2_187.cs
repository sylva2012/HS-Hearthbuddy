using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_187 : SimTemplate //* 藏宝海湾保镖 Booty Bay Bodyguard
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
