using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_127 : SimTemplate //* 银背族长 Silverback Patriarch
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
