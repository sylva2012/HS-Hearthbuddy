using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_118 : SimTemplate //* 岩浆暴怒者 Magma Rager
	{
		//
		//
		
		
	}
}
