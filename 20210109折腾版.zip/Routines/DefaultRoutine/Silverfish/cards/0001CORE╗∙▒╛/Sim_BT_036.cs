using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BT_036 : SimTemplate //* 协同打击 Coordinated Strike
	{
		//Summon three 1/1_Illidari with <b>Rush</b>.
		//召唤三个1/1并具有<b>突袭</b>的伊利达雷。
		
		
	}
}
