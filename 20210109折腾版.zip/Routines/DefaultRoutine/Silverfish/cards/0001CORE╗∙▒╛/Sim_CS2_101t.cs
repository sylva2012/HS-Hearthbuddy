using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_101t : SimTemplate //* 白银之手新兵 Silver Hand Recruit
	{
		//
		//
		
		
	}
}
