using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_mirror : SimTemplate //* 镜像 Mirror Image
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
