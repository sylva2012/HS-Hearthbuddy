using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_232 : SimTemplate //* 埃隆巴克保护者 Ironbark Protector
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
