using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_DFX_004 : SimTemplate //* Holy Healing Dummy FX Holy Healing Dummy FX
	{
		//Holds the FX for playing Holy Healing FX.
		//Holds the FX for playing Holy Healing FX.
		
		
	}
}
