using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_DFX_005 : SimTemplate //* Flamestrike Dummy FX Flamestrike Dummy FX
	{
		//Holds the FX for playing Flamestrike FX.
		//Holds the FX for playing Flamestrike FX.
		
		
	}
}
