using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_033 : SimTemplate //* 水元素 Water Elemental
	{
		//<b>Freeze</b> any character damaged by this minion.
		//<b>冻结</b>任何受到该随从伤害的角色。
		
		
	}
}
