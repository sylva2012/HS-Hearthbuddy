using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BCON_001 : SimTemplate //* 致命狙击 Deadeye
	{
		//For the rest of the game,your Hero Power can target minions.
		//在本局对战的剩余时间内，你的英雄技能能够以随从为目标。
		
		
	}
}
