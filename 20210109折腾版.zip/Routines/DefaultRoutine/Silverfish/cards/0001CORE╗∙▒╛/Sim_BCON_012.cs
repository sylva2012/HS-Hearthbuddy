using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BCON_012 : SimTemplate //* 拯救之手 Hand of Salvation
	{
		//<b>Secret:</b> When your second minion dies in a turn, return it to life.
		//<b>奥秘：</b>在一回合中当你的第二个随从死亡时，将其复活。
		
		
	}
}
