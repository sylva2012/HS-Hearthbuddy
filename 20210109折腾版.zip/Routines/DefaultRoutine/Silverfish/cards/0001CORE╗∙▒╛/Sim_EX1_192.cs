using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_192 : SimTemplate //* 圣光闪耀 Radiance
	{
		//Restore #5 Health to your hero.
		//为你的英雄恢复#5点生命值。
		
		
	}
}
