using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_119 : SimTemplate //* 绿洲钳嘴龟 Oasis Snapjaw
	{
		//
		//
		
		
	}
}
