using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_DFX_003 : SimTemplate //* Frost Nova Dummy FX Frost Nova Dummy FX
	{
		//Holds the FX for playing Frost Nova FX.
		//Holds the FX for playing Frost Nova FX.
		
		
	}
}
