# 炉石兄弟个人策略分享

#### 介绍
炉石兄弟吧 4.1 版本兄弟个人策略分享，仅吧友交流使用，侵删。

**仅供学习免费使用，严禁贩卖。**

兄弟折腾地址见文章底部，本人不会以任何形式出售兄弟脚本，出售兄弟的商家请至少不要删除界面中的伏笔反馈按钮。

使用任意一套卡组请在自定义策略中切换到对应的卡组策略。

提交**伏笔**请到 **Routines\DefaultRoutine\Silverfish\Test\Data\对局记录** 目录下找到对应回合的对局txt文本，复制文本的内容新建一个**issue**，标题为**建议打法**，内容为**复制的全部文本信息**。
**请不要在评论区给出打法建议而不给对应场面信息，所有伏笔提交 issue！！！**

PS. Test 奥秘法策略由 Tech 大佬提供，提交奥秘法伏笔反馈请到 https://gitee.com/thatcool/HSAi

大多数情况下伏笔只提交当前回合第 0 步操作也就是满费用的即可，如果没有随机情况导致计算结果不一致，兄弟会计算当前回合每一步操作后按顺序行动。

#### 如何快速更新策略
1. 首先确保你已经安装了 Git，如果没有，请点击[此处](https://github.com/git-for-windows/git/releases/download/v2.31.1.windows.1/Git-2.31.1-64-bit.exe)或者访问[官网](https://git-scm.com/downloads)完成下载安装。
2. 点击兄弟【一键更新策略】按钮即可将策略更新到最新版本。
3. 重新打开兄弟。

ps. 更新结果显示最新的更新记录在5.13日之前的还请重新下载一遍或者点击[这里](https://wwa.lanzoui.com/irTIxpa6b2j)下载更新文件到兄弟目录下运行修复无法正常更新的问题（不好意思之前地址写错了）。

#### 使用说明
策略完全基于炉石兄弟吧 4.1 版本兄弟。

使用请**删除 \Routines\DefaultRoutine 目录**，将下载得到的 DefaultRoutine 复制到原 \Routines 目录下

请尽量使用英雄**初始皮肤**（非异画英雄技能）和初始幸运币。

#### 当前支持卡组

##### 鱼人萨
狂野套牌：AAEBAaoIBOAFhBfG0QOo7gMN2wOnCL8Xt2ydwgKLzgKMlAO1mAPKqwOU6AOz6APd7AOV8AMA

#####  标准模式骑士
策略选择：骑士

螃蟹削了，能正确识别，但是没啥用，自己随便换两张带着吧

奥秘：AAECAYsWBpboA5HsA9vuA+fwA+qfBMigBAzKwQOezQOO1AOD3gOF3gOR5APM6wPO6wPP6wPj6wOanwTrnwQA

中速骑：AAECAYsWCPy4A8rRA4rSA5HsA+fwA6iKBLCKBKOgBAv7uAPKwQOezQO/0QOF3gOR5APM6wPj6wOanwTJoATRoAQA

圣契：不推荐自己随便找一套吧

自己根据需要替换卡牌吧，魔像师卡扎库斯暂不支持

#####  小丑德

自动化测试之前的产物，很多地方处理的不好，不太推荐

标准套牌：AAECAZICApXkA6iKBA7ougOVzQO60AO80AOT0QPe0QPw1AP+2wPm4QP36AO+7APe7AOJnwSunwQA

##### 动物园
更新： AAEDAaPDAwizlgTVlgTZlgTrlgTtlgSCoQS5oQTDoQQL+5UEgaEErqEEsqEE06EE7qEEnaIEoaIEo6IEv6IEw6MEAA==

来自 [nga](https://bbs.nga.cn/read.php?tid=26092278)

##### 经典T7猎
经典套牌: AAEDAR8CgqEE3KEEDoWWBJ2WBKGWBMCWBMyWBNGWBPiWBLGXBIGhBL2hBNGhBM2iBM+iBKKjBAA=

来自 [hsreplay.net](https://hsreplay.net/decks/JLzTkfLsBliNSYncejswse/#gameType=RANKED_CLASSIC)

不太喜欢猎人印记换了两张狼人渗透者的版本 AAEDAR8CgqEE3KEEDp2WBKGWBMCWBMyWBNGWBPiWBLGXBIGhBLShBL2hBNGhBM2iBM+iBKKjBAA=

##### 奥秘法
策略选择: test

策略作者：Tech

狂野套牌：AAEBAf0EBsAB67oCv6QDkOEDleEDwfADDLsC7AX3Dde2Aoe9AsHBAo/TAr6kA92pA/SrA8K4A5HhAwA=

##### 防战

经典套牌（特化针对动物园版本，遇到防战基本可以直接投）： AAEDAQcImpYEiqIEmKIExqIE2aIElqMEn6ME0qMEC5eWBJiWBK+WBPOWBP+WBLGhBLmiBL6iBMCiBMOiBJ2jBAA=


#### 添加自定义策略（惩罚）简易教程
1. 复制文件夹 Routines\DefaultRoutine\Silverfish\behavior\rush 到同级目录
2. 修改 Behavior怼脸模式.cs 文件中 BehaviorRush 和 "怼脸模式" 为任意其他名称，比如想要组建鱼人萨的策略就可以把 BehaviorRush 替换为 Behavior鱼人萨，同时可以顺便把文件中 "怼脸模式" 修改为 "鱼人萨"
3. 在 GetSpecialCardComboPenalty 函数中修改你的惩罚，具体写法参考其他 Behavior
4. 配置 _mulligan.txt，设置留牌策略
5. 打开兄弟，在 配置->策略->策略模式切换 中选择你新加入的策略
- 如有文件配置不理解，各级目录说明参考 http://blog.wjhwjhn.com/archives/16/
- GetSpecialCardComboPenalty 函数中返回值为负数表示鼓励兄弟出这张卡，正数表示不推荐出这张卡，值越大程度越高，经典惩罚配置例子参考 https://www.cnblogs.com/dch0319/p/13353571.html
- 卡基本上都有（指自动生成的空卡），配置惩罚的时候直接在 case "这里写需要加惩罚的卡牌的中文名称": 里面写就行

#### 自动化测试简易教程
- 调整策略的过程中很容易出现“为什么兄弟要这么打不那么打的问题”，光靠游戏内的测试是非常低效的，这时候我们就需要用到 VS 进行调试，具体教程参考 https://gitee.com/thatcool/HSAi ，这里假设您已经能够运行工程项目不报错，说明一下简易流程

1. 运行产生的对局记录会存放在 **Routines\DefaultRoutine\Silverfish\Test\Data\对局记录** 目录下的相应 txt 文本文档中。
2. 在**Routines\DefaultRoutine\Silverfish\Test\Data** 目录下新建策略对应的文件夹，之后在 AutoJudge.cs 中修改需要测试的文件夹和策略信息。
3. 运行 AutoJudge.cs，生成计算结果保存在同名对应的 .result 文件下，并且与同名对应的 .answer 文件比对打法，如果结果不相符进行提示。
4. 调试完毕后，将打法正确的.result文件后缀改为.answer，以便下次测试时进行检查。

**PS.注意项目必须引入兄弟及目录下的所有 .dll 后缀文件，否则会报错**

#### 参考资料
兄弟目录介绍，非常详细：http://blog.wjhwjhn.com/archives/16/

炉石传说卡牌数据库：https://hs.fbigame.com/

炉石大数据： https://hsreplay.net/

留牌策略转文字：http://ls.varc.cn/

调试：https://gitee.com/thatcool/HSAi

中控源码：https://github.com/V-arc/HearthbuddyHelper

大佬的博客：

https://www.cnblogs.com/varc/

https://www.cnblogs.com/chucklu/category/1519356.html

https://www.cnblogs.com/dch0319/

**另外尤其感谢 [Tech](https://gitee.com/thatcool/HSAi) 大佬提供的自动化测试框架以及对兄弟策略的大量优化工作，当前版本策略的整体框架完全来自于 Tech 大佬的版本。**


#### 附

原来已经有人在维护兄弟的获取途径了，Github项目地址： https://github.com/lesuixin/Hearthstone-Hearthbuddy ，或者直接 GitHub 搜索炉石，第一个项目就是他的，关于如何使用兄弟的说明非常详细了。

主程序[下载地址](https://drive.google.com/file/d/12SG8Vs7wmZjkzT7dEW6SWQYyivlviq4p/view?usp=sharing) 

Q. 为啥网址打不开？

A. 因为网址不存在，需要**魔法**才能打开；该版本献给那些有一定操作能力并且愿意折腾的兄弟的，
事实上兄弟的限制基本上都是人为设置为了防止兄弟完全泛滥失控的，请理解这一点，如果来杠，那么**你说的对**。

**该项目建立的目的仅仅是为了满足个人对策略研究的兴趣，个人精力有限需要同好帮我找到各种意想不到的伏笔修正以优化兄弟的打法。根据个人主观意愿随时可能做出停更乃至删库跑路的决定，还望见谅。**