using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BT_323 : SimTemplate //* 盲眼监视者 Sightless Watcher
	{
		//<b>Battlecry:</b> Look at 3 cards in your deck. Choose one to put on top.
		//<b>战吼：</b>检视你牌库中的三张牌。选择一张置于牌库顶。
		
		
	}
}
