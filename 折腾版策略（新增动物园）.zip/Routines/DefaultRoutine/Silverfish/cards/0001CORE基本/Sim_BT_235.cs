using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BT_235 : SimTemplate //* 混乱新星 Chaos Nova
	{
		//Deal $4 damage to all_minions.
		//对所有随从造成$4点伤害。
		
		
	}
}
