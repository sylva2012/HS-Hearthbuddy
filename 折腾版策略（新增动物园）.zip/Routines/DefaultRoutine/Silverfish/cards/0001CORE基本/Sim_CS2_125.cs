using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_125 : SimTemplate //* 铁鬃灰熊 Ironfur Grizzly
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
