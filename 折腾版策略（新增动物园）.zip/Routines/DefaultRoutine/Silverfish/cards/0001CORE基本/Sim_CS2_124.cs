using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_124 : SimTemplate //* 狼骑兵 Wolfrider
	{
		//<b>Charge</b>
		//<b>冲锋</b>
		
		
	}
}
