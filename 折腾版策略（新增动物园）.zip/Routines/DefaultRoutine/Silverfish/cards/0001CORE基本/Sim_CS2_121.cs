using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_121 : SimTemplate //* 霜狼步兵 Frostwolf Grunt
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
