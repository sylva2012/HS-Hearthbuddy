using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_162 : SimTemplate //* 竞技场主宰 Lord of the Arena
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
