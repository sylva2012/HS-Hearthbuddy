using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_172 : SimTemplate //* 血沼迅猛龙 Bloodfen Raptor
	{
		//
		//
		
		
	}
}
