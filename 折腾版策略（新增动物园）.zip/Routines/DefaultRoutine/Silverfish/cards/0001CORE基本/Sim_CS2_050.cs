using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_050 : SimTemplate //* 灼热图腾 Searing Totem
	{
		//
		//
		
		
	}
}
