using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_HERO_07 : SimTemplate //* 古尔丹 Gul'dan
	{
		//
		//
		
		
	}
}
