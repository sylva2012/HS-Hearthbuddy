using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_191 : SimTemplate //* 瘟疫使者 Plaguebringer
	{
		//<b>Battlecry:</b> Give a friendly minion <b>Poisonous</b>.
		//<b>战吼：</b>使一个友方随从获得<b>剧毒</b>。
		
		
	}
}
