using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BCON_008 : SimTemplate //* 大自然的勇士 Nature's Champion
	{
		//Return a friendly minion to your hand and give it +5/+5.
		//将一个友方随从移回你的手牌，并使其获得+5/+5。
		
		
	}
}
