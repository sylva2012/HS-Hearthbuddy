using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_186 : SimTemplate //* 作战傀儡 War Golem
	{
		//
		//
		
		
	}
}
