using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_skele11 : SimTemplate //* 骷髅 Skeleton
	{
		//<b></b>
		//<b></b>
		
		
	}
}
