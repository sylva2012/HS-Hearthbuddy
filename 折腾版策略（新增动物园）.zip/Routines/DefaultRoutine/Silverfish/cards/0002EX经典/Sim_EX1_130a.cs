using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_130a : SimTemplate //* 防御者 Defender
	{
		//
		//
		
		
	}
}
