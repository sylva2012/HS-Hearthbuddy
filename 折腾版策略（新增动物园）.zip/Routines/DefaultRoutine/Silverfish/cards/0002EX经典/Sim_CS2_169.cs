using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_169 : SimTemplate //* 幼龙鹰 Young Dragonhawk
	{
		//<b>Windfury</b>
		//<b>风怒</b>
		
		
	}
}
