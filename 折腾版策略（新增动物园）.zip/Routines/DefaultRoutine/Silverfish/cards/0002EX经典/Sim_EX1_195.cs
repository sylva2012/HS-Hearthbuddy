using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_195 : SimTemplate //* 库尔提拉斯教士 Kul Tiran Chaplain
	{
		//<b>Battlecry:</b> Give a friendly minion +2 Health.
		//<b>战吼：</b>使一个友方随从获得+2生命值。
		
		
	}
}
