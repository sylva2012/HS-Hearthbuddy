using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_028 : SimTemplate //* 荆棘谷猛虎 Stranglethorn Tiger
	{
		//<b>Stealth</b>
		//<b>潜行</b>
		
		
	}
}
