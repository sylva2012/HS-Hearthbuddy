using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_188 : SimTemplate //* 贫瘠之地饲养员 Barrens Stablehand
	{
		//<b>Battlecry:</b> Summon a random Beast.
		//<b>战吼：</b>随机召唤一只野兽。
		
		
	}
}
