using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_186 : SimTemplate //* 军情七处渗透者 SI:7 Infiltrator
	{
		//<b>Battlecry:</b> Destroy a random enemy <b>Secret</b>.
		//<b>战吼：</b>随机摧毁一个敌方<b>奥秘</b>。
		
		
	}
}
