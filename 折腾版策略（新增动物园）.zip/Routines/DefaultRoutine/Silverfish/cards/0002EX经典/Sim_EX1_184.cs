using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_184 : SimTemplate //* 正义 Righteousness
	{
		//Give your minions <b>Divine Shield</b>.
		//使你的所有随从获得<b>圣盾</b>。
		
		
	}
}
