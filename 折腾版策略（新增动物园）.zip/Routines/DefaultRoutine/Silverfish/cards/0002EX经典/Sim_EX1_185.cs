using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_185 : SimTemplate //* 攻城恶魔 Siegebreaker
	{
		//<b>Taunt</b>Your other Demons have +1 Attack.
		//<b>嘲讽</b>你的其他恶魔获得+1攻击力。
		
		
	}
}
