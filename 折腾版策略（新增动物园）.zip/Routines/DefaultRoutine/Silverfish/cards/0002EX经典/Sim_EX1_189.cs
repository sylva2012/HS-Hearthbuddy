using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_189 : SimTemplate //* 光明之翼 Brightwing
	{
		//<b>Battlecry:</b> Add a random <b>Legendary</b> minion to your_hand.
		//<b>战吼：</b>随机将一张<b>传说</b>随从牌置入你的手牌。
		
		
	}
}
