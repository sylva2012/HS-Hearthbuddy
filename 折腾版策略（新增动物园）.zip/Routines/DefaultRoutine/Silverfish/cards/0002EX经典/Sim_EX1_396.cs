using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_396 : SimTemplate //* 魔古山守望者 Mogu'shan Warden
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
