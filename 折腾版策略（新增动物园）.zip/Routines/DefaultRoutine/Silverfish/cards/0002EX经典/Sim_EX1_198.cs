using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_198 : SimTemplate //* 娜塔莉·塞林 Natalie Seline
	{
		//<b>Battlecry:</b> Destroy a minion and gain its Health.
		//<b>战吼：</b>消灭一个随从并获得其生命值。
		
		
	}
}
